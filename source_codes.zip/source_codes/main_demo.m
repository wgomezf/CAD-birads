clearvars; close all; clc;

addpath('random_forest','CAD','features','data');

if ~exist('CADcat.mat','file')
    load('features.mat');
    CAD = CADtrain(data,'cat'); % Train CAD
    save(fullfile(pwd,'data','CADcat.mat'),'CAD')
else
    load CADcat.mat;
end



files = {'A-1_B_3113_1.RIGHT_MLO.mat';
         'A-1_A_1093_1.RIGHT_MLO.mat'}; % Mammographic images

c = [0 1 0;1 0 0];
figure('color',[1 1 1],'Position',[100 100 660 600])
ha = tight_subplot(1,2,[.01 .01],[.1 .01],[.01 .01]);
for i = 1:2
    load(files{i});
    % Resize image to 10% of original size
    I      = imresize(I,0.1,'bicubic');
    I      = uint8(I/256); % convert to 8-bit
    breast = imresize(breast,0.1,'nearest');
    mass   = imresize(mass,0.1,'nearest');

    % Calculate BI-RADS features
    % Shape features
    data.features.shape   = shape_features(mass);
    % Margin features
    data.features.margin  = margin_features(mass);
    % Density features
    data.features.density = density_features(I,breast);
    % Predict with CAD
    Out = CADpredict(data,CAD);   

    % Show output
    labels = table2array(Out.Labels);
    axes(ha(i));
    imshow(labeloverlay(I,mass,'Colormap',c(Out.PATHOLOGICAL.Labels,:),'Transparency',0));
    axis('on', 'image');
    set(gca,'XTick',[],'YTick',[],'XColor', 'k','YColor', 'k');
    text(10,size(I,1)-80,sprintf('Shape: %s',labels{1}),'Color','w','FontSize',15);
    text(10,size(I,1)-60,sprintf('Margin: %s',labels{2}),'Color','w','FontSize',15);
    text(10,size(I,1)-40,sprintf('Density: %s',labels{3}),'Color','w','FontSize',15);
    text(10,size(I,1)-20,sprintf('Pathology: %s',labels{4}),'Color','w','FontSize',15);
    box on;
end