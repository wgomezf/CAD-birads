% DENSITY_FEATURES Extract texture features for density model.
%   X = DENSITY_FEATURES(I,BW) extracts texture features robust to intensity
%   changes in the mammogram I. BW is a binary mask with the breast tissue
%   region. The features are based on the ranklet transform and GLCM-based 
%   textures features. The output X is a feature vector with 108 textures
%   features.

% ------------------------------------------------------------------------
%   Cinvestav-IPN (Mexico)
%   DENSITY_FEATURES Version 1.0 (Matlab R2020a)
%   July 2020
%   Copyright (c) 2020, Wilfrido Gomez Flores
% ------------------------------------------------------------------------

function [xT,fT] = density_features(I,BW)
% Calculate ranklets
J = multiranklet(I,[2 4 8]); 
% Calculate GLCM from ranklets
R = J(:);
xT = [];
fT = [];
Offset = [0 1; -1 1; -1 0; -1 -1];  % Four orientations and 1-pixel distance
Q = 16;	% Quantization level
rks = {'_H_R2','_V_R2','_D_R2','_H_R4','_V_R4','_D_R4','_H_R8','_V_R8','_D_R8'};
for k = 1:length(R)
    M = R{k};
    M(~BW)= 0;
    CM = graycomatrix(M,'Of',Offset,'NumLevels',Q,'GrayLimits',[-1 1]);
    [i,j] = meshgrid(1:Q,1:Q);
    idx1 = (i+j)-1;
    idx2 = abs(i-j)+1;
    tfeats = zeros(4,12);
    for l = 1:4
        CMaux = CM(:,:,l);
        % Normalize GLCM
        CM_sum = sum(CMaux(:));
        Pij = CMaux./CM_sum;  % Normalize each CM
        % 
        u_x = sum(sum(i.*Pij));
        u_y = sum(sum(j.*Pij));
        %
        p_xplusy  = zeros(2*Q - 1,1); %[1]
        p_xminusy = zeros(Q,1);       %[1]
        for aux = 1:max(idx1(:))
           p_xplusy(aux) =  sum(Pij(idx1==aux));
        end
        for aux = 1:max(idx2(:))
           p_xminusy(aux) = sum(Pij(idx2==aux));
        end
        % Contrast
        tfeats(l,1) = sum(sum((abs(i-j).^2).*Pij));
        % Dissimilarity
        tfeats(l,2) = sum(sum(abs(i-j).*Pij));
        % Energy
        tfeats(l,3) = sum(sum(Pij.^2));
        % Entropy
        tfeats(l,4) = -sum(sum(Pij.*log(Pij+eps)));
        % Homogeneity Matlab
        tfeats(l,5) = sum(sum(Pij./(1+abs(i-j)))); 
        % Inverse difference moment normalized
        tfeats(l,6) = sum(sum(Pij./(1+(((i-j).^2)./(Q.^2)))));
        % Maximum probability
        tfeats(l,7) = max(Pij(:));
        % Cluster Prominence
        tfeats(l,8) = sum(sum(Pij.*((i+j-u_x-u_y).^4)));
        % Cluster Shade
        tfeats(l,9) = sum(sum(Pij.*((i+j-u_x-u_y).^3)));
        % AutoCorrelation
        s_x = sum(sum(Pij.*((i-u_x).^2)))^0.5;
        s_y = sum(sum(Pij.*((j-u_y).^2)))^0.5;
        tfeats(l,10) = sum(sum(Pij.*(i.*j)));
        % Correlation Matlab
        corm = sum(sum(Pij.*(i-u_x).*(j-u_y)));
        tfeats(l,11) = corm/((s_x*s_y)+0.0001);
        % Correlation Haralick
        tfeats(l,12) = ((sum(sum(Pij.*(i.*j))))-u_x*u_y)/(s_x*s_y+eps);
    end
    x2 = mean(tfeats,1); % Mean value over orientations
    feats2 = {['contr' rks{k}],['dissi' rks{k}],['energ' rks{k}],['entro' rks{k}],...
              ['homom' rks{k}],['idmnc' rks{k}],['maxpr' rks{k}],['cprom' rks{k}],...
              ['cshad' rks{k}],['autoc' rks{k}],['corrm' rks{k}],['corrh' rks{k}]};
    xT = cat(2,xT,x2);
    fT = cat(2,fT,feats2);
end