% MARGIN_FEATURES Extract morphological features for margin model.
%   X = MARGIN_FEATURES(BW) extracts morphological features from the tumor
%   region defined by the binary mask BW. The features are based on the
%   signature of the tumor boundary. The output X is a feature vector with 
%   nine margin features.

% ------------------------------------------------------------------------
%   Cinvestav-IPN (Mexico)
%   MARGIN_FEATURES Version 1.0 (Matlab R2020a)
%   July 2020
%   Copyright (c) 2020, Wilfrido Gomez Flores
% ------------------------------------------------------------------------

function [xM,fM] = margin_features(BW)
BW = logical(BW);
BW = bwareaopen(BW,2);
% Number of undulations [3] *
und = undulations(BW);
% Normalized radial lenght (NEW) [4]
[znrl,fnrl] = new_nrl(BW);
% Fractal [5]*
[frc,ffrc] = fractal(BW);
% Features
xM = [und znrl frc];
fM = {'undulation',fnrl{:},ffrc{:}};
%***********************************************************************
function MU = undulations(BW)
[y,x] = find(BW);
xmn = min(x);
xmx = max(x);
ymn = min(y);
ymx = max(y);
BW2 = BW(ymn:ymx,xmn:xmx);
BW2 = padarray(BW2,[1 1],0,'both');
% Compute distance map
D = bwdist(~BW2);
% Inscribed circle distance map
[M,N] = size(BW2);
[y,x] = find(D==max(D(:)));
xc = mean(x); yc = mean(y);
[X,Y] = meshgrid(1:N,1:M);
C = sqrt((X-xc).^2 + (Y-yc).^2);
% Get lobules with the maximum inscribed circle
r = max(D(:)); % Radius
BW3 = (BW2-(C<=r))>0;
D2 = bwdist(~BW3);
BW3(D2<2) = 0;
BW3 = bwareaopen(BW3,10);
L = bwlabel(BW3);
MU = max(L(:));
%***********************************************************************
function [z,f] = new_nrl(BW)
% Parametrize boundary
[x,y] = param_bound(BW);
xn = x-mean(x);
yn = y-mean(y);
n = numel(xn);
% Find maximum/minimum
r = sqrt(xn.*xn + yn.*yn)/sqrt(bwarea(BW)/pi);
s = 20;
r = [r(n-s+1:n);r;r(1:s)];
t = 3;
while t<15
    r = smooth(r,t);
    t = t+2;
end
r = r(s+1:end-s);
th = (1:n)';
[~,k1] = findpeaks(r,th);
[~,k2] = findpeaks(max(r)-r,th);
k = unique([1;k1;k2;n]);
% Features directly from signature      
ar = sum(r(r>1)-1)/n; % External area ratio
cr = sum(abs(diff(r>1)));  % mean crossing
npd = numel(k)-1;     % number of protuberances and depresions
md = mean(abs(1-r));  % mean absolute distance
mx = max(abs(1-r));   % max absolute distance
m = numel(k);
% Sum squared error
d2 = [];
for i = 1:m-1
    l = linspace(r(k(i)),r(k(i+1)-1),k(i+1)-k(i));
    s = r(k(i):k(i+1)-1)';
    d2 = cat(2,d2,l-s);
end
% Power spectrum entropy
yf = fft(d2);
ps = abs(yf).^2;
p = ps/sum(ps);
ent = -sum(p.*log2(p+eps))/(log2(n));
z = [ar cr npd md mx ent];
f = {'AreaRatio','Crossing','NumMaxMin','MeanDist','MaxDist','Entropy'};
%******************************************************************
function [x,feats] = fractal(BW)
% Normalized signature space
[x,y] = param_bound(BW);
xn = x-mean(x);
yn = y-mean(y);
n = numel(xn);
r = sqrt(xn.*xn + yn.*yn);
r = smooth(r,5);
r = r/max(r);
t = linspace(0,1,n);
% Ruler method
rt = [t;r'];
D = eucdist(rt,rt);
E = logical(tril(ones(size(D)),0));
D(E) = NaN;
rsz = 0.05:0.025:0.2;
countrsz = zeros(1,numel(rsz));
for i = 1:numel(rsz)
    y = 1;
    c = 0;
    while ~isempty(y)
       [~,y] = find(D(y,:)>=rsz(i),1,'first');
       c = c+1;
    end
    countrsz(i) = c-1;
end
[pC,~] = polyfit(log(1./rsz),log(countrsz),1);
Druler = pC(1);
% Box-counting method
bsz = 1./(2.^(2:7));
countbsz = zeros(1,numel(bsz));
for k = 1:numel(bsz)
    qL = 1/bsz(k);
    rQ = floor(r*qL)/qL; %quantizing
    tQ = floor(t*qL)/qL;
    l  = 0:bsz(k):1;
    nl = numel(l);
    c = zeros(nl);
    for i = 1:nl
       rQi = rQ(tQ==l(i));
       for j = 1:nl
           if sum(rQi==l(j))>0
               c(j,i) = 1;
           end
       end
    end
    countbsz(k) = sum(c(:));
end
[pC,~] = polyfit(log(1./bsz),log(countbsz),1);
Dbox = pC(1);
x = [Druler Dbox];
feats = {'Druler' 'Dbox'};
%***********************************************************************
function [x,y] = param_bound(BW)
Baux = bwboundaries(BW);
x = Baux{1}(:,1);
y = Baux{1}(:,2);
%***********************************************************************
function D = eucdist(A, B)
D = sqrt(abs(bsxfun(@plus,dot(B,B,1),dot(A,A,1)') - 2*(A'*B)));