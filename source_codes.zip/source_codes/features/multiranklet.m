% MULTIRANKLET Multichannel decomposition by ranklet transform.
%   J = MULTIRANKLET(I,RESOLUTIONS) performs the multichannel decomposition
%   of input image I by the ranklet transform, where RESOLUTIONS is a vector 
%   1xn of integers with the resolution values. J is a cell array where the 
%   columns represent the resolutions and the rows the orientations 
%   (1st: horizontal, 2nd: vertical and 3th: diagonal).
%
%   NOTE: In Windows, for running function "unifiedrankletPThreadWinMEX001.mewx64"
%   first copy the files "pthreadGC2.dll" and "pthreadVC2.dll" (provided in the
%   ZIP archive "...\C functions\Ranklet_source.zip") to the directory 
%   "C:\Windows\System32".
%
%   Reference:
%   ----------
%   M. Masotti, "A ranklet-based image representation for mass classification
%   in digital mammograms," Medical Physics, vol. 33, pp. 3951-3961, 2006.

% ------------------------------------------------------------------------
%   Cinvestav-IPN (Mexico)
%   MULTIRANKLET Version 1.0 (Matlab R2014a Unix)
%   November 2016
%   Copyright (c) 2016, Arturo Rodriguez Cristerna, Wilfrido Gomez Flores
% ------------------------------------------------------------------------

function RT = multiranklet(I,r)
str = computer; % Verify the kind of operative system for ranklet C code
I = uint8(I);
R = r(end);
Ri = numel(r);
T = zeros(size(I,1),size(I,2),Ri);
I = padarray(I,[R R],'symmetric','both');
[Mi,Ni] = size(I);
RT = cell(3,Ri);
xc = R+1:Ni-R;
yc = R+1:Mi-R;
for i = 1:Ri
    % Ranklet transform
    if strcmpi(str,'MACI64')||strcmpi(str,'GLNXA64')
        [H,V,D] = unifiedrankletPThreadMEX001(I,r(i));
    elseif strcmpi(str,'PCWIN64')
        [H,V,D] = unifiedrankletPThreadWinMEX001(I,r(i));
    end
    RT{1,i}  = H(yc,xc);
    RT{2,i}  = V(yc,xc);
    RT{3,i}  = D(yc,xc);
end