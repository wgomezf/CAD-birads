% CADPREDICT Predict with a computer aided-diagnosis system.
%   OUT = CADPREDICT(DATA,CAD) classifies a breast tumor with a compute-aided
%   diagnosis (CAD) system. DATA is a structure with the following fields:
%       - data.features.shape: region-based features (N samples-by-Ds features)
%       - data.margin.shape: margin-based features (N samples-by-Dm features)
%       - data.density.shape: texture features (N samples-by-Dt features)
%   OUT is a structure with the predicted class labels and posterior
%   probabilities of samples in DATA.
%   
%   Reference:
%   ---------
%   J. Hernandez-Lopez and W. Gomez-Flores, "A comprehensive computer-aided 
%   diagnosis system based on the BI-RADS lexicon for mammographic masses", 
%   IEEE Acces, in press, 2020.

% ------------------------------------------------------------------------
%   Cinvestav-IPN (Mexico)
%   CADPREDICT Version 1.0 (Matlab R2020a)
%   July 2020
%   Copyright (c) 2020, Wilfrido Gomez Flores
% ------------------------------------------------------------------------

function Out = CADpredict(data,CAD)

if strcmpi(CAD.Type,'CATEGORICAL')||strcmpi(CAD.Type,'NUMERICAL')
    OS = classify_RF(data.features.shape,CAD.BIRADS.Shape.Model);     % (Equation 7)
    OM = classify_RF(data.features.margin,CAD.BIRADS.Margin.Model);   % (Equation 8)
    OD = classify_RF(data.features.density,CAD.BIRADS.Density.Model); % (Equation 9)
    % Choose data type
    if strcmpi(CAD.Type,'CATEGORICAL')
        % (Equation 10)
        X = array2table([CAD.BIRADS.Shape.Attributes(OS.Labels)'...
                         CAD.BIRADS.Margin.Attributes(OM.Labels)'...
                         CAD.BIRADS.Density.Attributes(OD.Labels)'],'VariableNames',{'Shape' 'Margin' 'Density'});
    elseif strcmpi(CAD.Type,'NUMERICAL')
        % (Equation 11)
        X = [OS.Scores OM.Scores OD.Scores];
    end
elseif strcmpi(CAD.Type,'CONVENTIONAL')
    X = [data.features.shape data.features.margin data.features.density]; % Section IV.B
end
OP = classify_RF(X,CAD.PATHOLOGICAL.Model); % (Equation 12)
% Predicted labels
Out.Type = CAD.Type;
if strcmpi(CAD.Type,'CATEGORICAL')||strcmpi(CAD.Type,'NUMERICAL')
    Out.Labels = array2table([CAD.BIRADS.Shape.Attributes(OS.Labels)'...
                              CAD.BIRADS.Margin.Attributes(OM.Labels)'...
                              CAD.BIRADS.Density.Attributes(OD.Labels)'...
                              CAD.PATHOLOGICAL.Attributes(OP.Labels)'],'VariableNames',{'Shape' 'Margin' 'Density' 'Pathology'});
    Out.BIRADS.Shape.Labels       = OS.Labels; 
    Out.BIRADS.Shape.Likelihood   = OS.Scores; 
    Out.BIRADS.Margin.Labels      = OM.Labels; 
    Out.BIRADS.Margin.Likelihood  = OM.Scores; 
    Out.BIRADS.Density.Labels     = OD.Labels; 
    Out.BIRADS.Density.Likelihood = OD.Scores; 
elseif strcmpi(CAD.Type,'CONVENTIONAL')
    Out.Labels = array2table(CAD.PATHOLOGICAL.Attributes(OP.Labels)','VariableNames',{'Pathology'});
end
Out.PATHOLOGICAL.Labels     = OP.Labels; 
Out.PATHOLOGICAL.Likelihood = OP.Scores; 