% CADTRAIN Train a computer aided-diagnosis system.
%   OUT = CADTRAIN(DATA,OPT) trains a computer aided-diagnosis system for
%   mammographic masses based on the BI-RADS lexicon. DATA is a structure
%   with the following fields:
%       - data.features.shape: region-based features (N samples-by-Ds features)
%       - data.margin.shape: margin-based features (N samples-by-Dm features)
%       - data.density.shape: texture features (N samples-by-Dt features)
%       - data.labels.shape: shape attributes labels (N samples-by-1)
%       - data.margin.shape: margin attributes labels (N samples-by-1)
%       - data.density.shape: density attributes labels (N samples-by-1)
%       - data.density.pathological: pathological labels (N samples-by-1)
%   OPT is a string indicating the type of CAD:
%       - OPT = 'cat' trains a CAD with categorical BI-RADS predictions
%       - OPT = 'num' trains a CAD with numerical BI-RADS predictions
%       - OPT = 'con' trains a conventional CAD
%   OUT is a structure with the trained CAD system, containing all the
%   lassification models based on random forest classifier.
%   
%   Reference:
%   ---------
%   J. Hernandez-Lopez and W. Gomez-Flores, "A comprehensive computer-aided 
%   diagnosis system based on the BI-RADS lexicon for mammographic masses", 
%   IEEE Acces, in press, 2020.

% ------------------------------------------------------------------------
%   Cinvestav-IPN (Mexico)
%   CADTRAIN Version 1.0 (Matlab R2020a)
%   July 2020
%   Copyright (c) 2020, Wilfrido Gomez Flores
% ------------------------------------------------------------------------

function CAD = CADtrain(data,opt)
% Obtain BI-RADS lexicon features
XS = data.features.shape;
XM = data.features.margin;
XD = data.features.density;
% Obtain actual labels
YS = data.labels.shape;
YM = data.labels.margin;
YD = data.labels.density;
YP = data.labels.pathological;
if strcmpi(opt,'cat')||strcmpi(opt,'num')
    % BI-RADS lexicon attributes
    OmegaS = {'ROUND','OVAL','LOBULAR','IRREGULAR'};
    OmegaM = {'NON-SPICULATED','SPICULATED'};
    OmegaD = {'FATTY','GLANDULAR','DENSE'};
    % Split train data for training lexicon models and  pathological model
    [tr1,tr2] = crossvalind('HoldOut',YP,0.5); 
    X1S = XS(tr1,:); Y1S = YS(tr1,:); % Shape data X1 set
    X1M = XM(tr1,:); Y1M = YM(tr1,:); % Margin data X1 set
    X1D = XD(tr1,:); Y1D = YD(tr1,:); % Density data X1 set
    % Train each BI-RADS lexicon model
    fS = train_RF(X1S,Y1S); % (Equation 7)
    fM = train_RF(X1M,Y1M); % (Equation 8)
    fD = train_RF(X1D,Y1D); % (Equation 9)
    % Map X2 data
    X2S = XS(tr2,:); %Y2S = YS(tr2,:); % Shape data X2 set
    X2M = XM(tr2,:); %Y2M = YM(tr2,:); % Margin data X2 set
    X2D = XD(tr2,:); %Y2D = YD(tr2,:); % Density data X2 set   
    Y2  = YP(tr2,:); % Pathological labels for X2 set
    OS  = classify_RF(X2S,fS);
    OM  = classify_RF(X2M,fM);
    OD  = classify_RF(X2D,fD);
    % Choose data type for mapped X2 set
    if strcmpi(opt,'cat')
        % (Equation 10)
        X2 = array2table([OmegaS(OS.Labels)' OmegaM(OM.Labels)' OmegaD(OD.Labels)'],'VariableNames',{'Shape' 'Margin' 'Density'});
    elseif strcmpi(opt,'num')
        % (Equation 11)
        X2 = [OS.Scores OM.Scores OD.Scores]; 
    end
elseif strcmpi(opt,'con')
    X2 = [XS XM XD]; % Section IV.B
    Y2 = YP;
else
    error('Only cat, num, or con options are allowed');
end
% Train pathological classifier
fP = train_RF(X2,Y2);  % (Equation 12)
% Outputs
if strcmpi(opt,'cat')||strcmpi(opt,'num')
    dtype = {'CATEGORICAL' 'NUMERICAL'};
    CAD.Type = dtype{[strcmpi(opt,'cat') strcmpi(opt,'num')]};
    CAD.BIRADS.Shape.Model = fS;
    CAD.BIRADS.Shape.Attributes = OmegaS;
    CAD.BIRADS.Margin.Model = fM;
    CAD.BIRADS.Margin.Attributes = OmegaM;
    CAD.BIRADS.Density.Model = fD;
    CAD.BIRADS.Density.Attributes = OmegaD;
elseif strcmpi(opt,'con')
    CAD.Type = 'CONVENTIONAL';
    CAD.BIRADS.Shape   = [];
    CAD.BIRADS.Margin  = [];
    CAD.BIRADS.Density = [];    
end
CAD.PATHOLOGICAL.Model = fP;
CAD.PATHOLOGICAL.Attributes = {'BENIGN','MALIGNANT'};