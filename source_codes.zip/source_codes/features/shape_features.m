% SHAPE_FEATURES Extract morphological features for shape model.
%   X = SHAPE_FEATURES(BW) extracts morphological features from the tumor
%   region defined by the binary mask BW. The features are based on region-based
%   descriptors. The output X is a feature vector with 20 shape features.

% ------------------------------------------------------------------------
%   Cinvestav-IPN (Mexico)
%   SHAPE_FEATURES Version 1.0 (Matlab R2020a)
%   July 2020
%   Copyright (c) 2020, Wilfrido Gomez Flores
% ------------------------------------------------------------------------

function [xF,fF] = shape_features(BW)
BW = logical(BW);
[CH,E] = convex_ellipse(BW);
sbw = regionprops(BW,'Area','Perimeter','Centroid','MajorAxisLength','MinorAxisLength');
sch = regionprops(CH,'Area','Perimeter','Centroid','MajorAxisLength','MinorAxisLength');
sel = regionprops(E,'Area','Perimeter','Centroid','MajorAxisLength','MinorAxisLength');
skl = bwmorph(BW,'skel',Inf);
% Solidity [1]*
sol = sbw(1).Area/sch(1).Area;
% Normalized residual value [2]*
nrv = bwarea(xor(BW,CH))/sbw(1).Area;
% Convexity [1]*
cnv = sch(1).Perimeter/sbw(1).Perimeter;
% Compactness [6] *
cmp = (2*sqrt(sbw(1).Area*pi))/sbw(1).Perimeter;
% Form factor [1]
frf = (4*pi*sbw(1).Area)/(sbw(1).Perimeter^2);
% Extent [1]*
[ext1,ext2] = extent(BW);
% Elliptic-normalized circumference [3]*
enc = sbw(1).Perimeter/sel(1).Perimeter;
% Elliptic-normalized skeleton [3]*
ens = bwarea(skl)/sel(1).Perimeter;
% Radial mean distance from lesion or Shape class [4] *
sc = radmeandist(BW,E); 
% Area difference with equivalent ellipse [5]*
adee = (sel(1).Area + sbw(1).Area - bwarea(BW&E))/sbw(1).Area;
% Symmetry (Sin publicar)
[zsym,fsym] = symmetry(BW);
% Features
xF = [sol nrv cnv cmp frf ext1 ext2 enc ens sc adee zsym];
fF = {'solidity','nrv','convexity','compacity',...
      'form_factor','extent_rect','extent_circ',...
      'enc','ens','rad_dist','adee',fsym{:}};
%************************************************************************
function [CH,E] = convex_ellipse(BW)
% Blob properties
BW_props = regionprops(BW,'Area','ConvexHull','Perimeter','Centroid');
% Convex hull
CH = roipoly(BW,BW_props(1).ConvexHull(:,1),BW_props(1).ConvexHull(:,2));
% Equivalente ellipse
xc = BW_props(1).Centroid(1); yc = BW_props(1).Centroid(2);
A = BW_props.Area;
[y,x] = find(BW);
[xx,yy] = meshgrid(1:size(BW,2),1:size(BW,1));
Sxx = (1/A)*sum((x-xc).^2);
Syy = (1/A)*sum((y-yc).^2);
Sxy = (1/A)*sum((x-xc).*(y-yc));
coef = (1/(4*Sxx*Syy - Sxy^2))*[Syy -Sxy;-Sxy Sxx];
a = coef(1,1); b = coef(1,2); c = coef(2,2);
E = (a*(xx-xc).^2 + 2*b*(xx-xc).*(yy-yc) + c*(yy-yc).^2) <= 1;
%************************************************************************
function [ext1,ext2] = extent(BW)
A = bwarea(BW);
[x,y] = find(bwperim(BW));
x = x-mean(x);
y = y-mean(y);
a = 90;
t = (0:a-1)*pi/180;
c = cos(t);
s = sin(t);
xr = x*c - y*s;
yr = x*s + y*c;
Dh = abs(max(xr,[],1)-min(xr,[],1));
Dv = abs(max(yr,[],1)-min(yr,[],1));
ext1 = max(A./(Dh.*Dv));            % Extent with respect a rectangle
rs = max(sqrt(xr.^2+yr.^2),[],1);
ext2 = max(A./(pi*rs.^2));          % Extent with respect a circle
%************************************************************************
function sc = radmeandist(BW,E)
[xe,ye] = param_bound(E);
[xb,yb] = param_bound(BW);
xc = mean(xb);
yc = mean(yb);
xe = xe-xc;
ye = ye-yc;
xb = xb-xc;
yb = yb-yc;
nre = sqrt(xe.^2+ye.^2);
nrb = sqrt(xb.^2+yb.^2);
uxe = xe./nre; uye = ye./nre;
uxb = xb./nrb; uyb = yb./nrb;
D1 = eucdist([uxb uyb]',[uxe uye]');
[~,k] = min(D1,[],2);
D2 = sqrt((xb - xe(k)).^2 + (yb - ye(k)).^2);
sc = mean(D2)/sqrt(bwarea(BW)/pi);
%-------------------------------------------------------------------
function D = eucdist(A, B)
D = sqrt(abs(bsxfun(@plus,dot(B,B,1),dot(A,A,1)')- 2*(A'*B)));
%************************************************************************
function [z,f] = symmetry(BW)
% Parametrize boundary
[x,y] = param_bound(BW);
% PCA
X = [x y];
Xm = bsxfun(@minus,X,mean(X,1));
C = cov(Xm);
[W,D] = eig(C);
[~,i] = sort(diag(D),'descend');
W = W(:,i);
X = X*W;
% Centralize
x = X(:,1)-mean(X(:,1));
y = X(:,2)-mean(X(:,2));
% Half parts of the first axis
[x1,y1,id] = shiftxy(x,y,y>0);
x1a = x1(id);  y1a = y1(id); 
x1b = x1(~id); y1b = y1(~id);
% Half parts of the second axis
[x2,y2,id] = shiftxy(x,y,x>0);
x2a = x2(id);  y2a = y2(id);
x2b = x2(~id); y2b = y2(~id);
% Rotate axes
[x1b,y1b] = rot(x1b,y1b,1);
[x2b,y2b] = rot(x2b,y2b,2);
[x2a,y2a] = rot(x2a,y2a,3);
% % Jaccard values
J1 = jaccard(x1a,y1a,x1b,y1b);
J2 = jaccard(x2a,y2a,x2b,y2b);
% % Proportional distance of half signatures
v = sqrt(bwarea(BW)/pi);
[pdmn1,pdmx1] = propdist(x1a,y1a,x1b,y1b,2*v);
[pdmn2,pdmx2] = propdist(x2a,y2a,x2b,y2b,2*v);
% Signatures comparison
[cor1,~] = symsign(x1a,y1a,x1b,y1b,v,1);
[cor2,err2] = symsign(x2a,y2a,x2b,y2b,v,0);
% Features
z = [J1 J2 pdmn1 pdmn2 pdmx1 pdmx2 cor1 cor2 err2];
f = {'SymArea1','SymArea2','PdistMean1','PdistMean2','PdistMax1','PdistMax2',...
     'Corr1','Corr2','MSE2'};
%************************************************************
function [x,y,id] = shiftxy(x,y,id)
k = 1;
v = id(end);
while v == id(end)
    id = circshift(id,k);
    x  = circshift(x,k);
    y  = circshift(y,k);
end
%************************************************************
function [cor,err] = symsign(x2a,y2a,x2b,y2b,v,opt)
[~,s1] = halfsign(x2a,y2a,v,opt);
[~,s2] = halfsign(x2b,y2b,v,not(opt));
c = abs(corrcoef(s1,s2)); 
cor = c(2,1);
err = mean((s1-s2).^2);
%------------------------------------------------------------
function [t1,s1] = halfsign(x2a,y2a,v,opt)
[t1,s1] = cart2pol(x2a,y2a);
s1 = s1/v;
if opt
   s1 = flipud(s1);
   t1 = flipud(t1); 
end
th   = t1*180/pi;
int_ = fix(th);
dec_ = th-int_;
id = dec_< 0.5;
dec_(id) = 0;
dec_(~id) = 0.5;
t1 = int_+dec_;
[~,d] = min(t1);
t1 = circshift(t1,-d+1);
s1 = circshift(s1,-d+1);
[t1,id] = unique(t1,'stable');
s1 = s1(id);
f = 0:0.5:179.5;
q1 = setdiff(f,t1)';
sq = interp1(t1,s1,q1,'linear','extrap');   % Resample x
a1 = zeros(1,360);
a1(ismember(f,t1)) = s1;
a1(ismember(f,q1)) = sq;
s1 = smooth(a1);
t1 = f;
%************************************************************
function [xr,yr] = rot(x,y,opt)
if opt == 1
    R = [1 0;0 -1];
elseif opt ==2
    R = [0 1;-1 0];
elseif opt == 3
    R = [0 1;1 0];
end
R2 = (R*[x y]')';
xr = R2(:,1);
yr = R2(:,2);
%************************************************************
function J1 = jaccard(x1a,y1a,x1b,y1b)
x1a = fix(x1a); y1a = fix(y1a);
x1b = fix(x1b); y1b = fix(y1b);
d = min(min(x1a),min(x1b))-1;
x1a = x1a-d;
x1b = x1b-d;
xl = ceil(max(max(x1a),max(x1b)));
yl = ceil(max(max(y1a),max(y1b)));
B1 = roipoly(zeros([yl xl]),x1a,y1a);
B2 = roipoly(zeros([yl xl]),x1b,y1b);
J1 = bwarea(B1&B2)/bwarea(B1|B2);
%************************************************************
function [pdmn,pdmx] = propdist(x2a,y2a,x2b,y2b,v)
D = eucdist([x2a y2a]',[x2b y2b]');
d1 = min(D,[],1)';
d2 = min(D,[],2);
pdmn = (mean(d1)+mean(d2))/v;
pdmx = (max(d1)+max(d2))/v;

%******************************************************************
function [x,y] = param_bound(BW)
Baux = bwboundaries(BW);
x = Baux{1}(:,1);
y = Baux{1}(:,2);