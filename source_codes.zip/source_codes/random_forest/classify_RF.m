% CLASSIFY_RF Classify data with random forest classifier.
%   OUT = CLASSIFY_RF(X,MODEL) classifies data in X (N samples-by-D features) 
%   using a random forest classifier, where MODEL is a structure with the 
%   RF parameters. OUT is a structure with both the predicted class labels 
%   and posterior probability estimations of samples in X.
%
%   NOTE: This function requires the "predict" function included in the 
%   Statistics and Machine Learning Toolbox.
%   
%   Reference:
%   ---------
%   Leo Breiman, "Random Forests", Machine Learning, vol. 45, no. 1, 
%   pp.  5-32, 2001.

% ------------------------------------------------------------------------
%   Cinvestav-IPN (Mexico)
%   CLASSIFY_RF Version 1.0 (Matlab R2020a)
%   July 2020
%   Copyright (c) 2020, Wilfrido Gomez Flores
% ------------------------------------------------------------------------

function Out = classify_RF(X,Model)
B = Model.Params.B;
C = Model.Params.C;
N = size(X,1);
% classify out-of-bag
Ypb = zeros(N,B);
Scr = zeros(N,C,B);
for i = 1:B
    [Ypb(:,i),Scr(:,:,i)] = predict(Model.Forest{i},X);
end
% Majority vote (Equation 4)
V = zeros(N,C);
for i = 1:N
    Ypi = Ypb(i,:);
    votes = accumarray(Ypi',ones(numel(Ypi),1),[C 1],@sum,0);
    V(i,:) = votes;
end
[~,Ypp] = max(V,[],2);
Out.Scores = mean(Scr,3); % Posterior probability (Equation 6)
Out.Labels = Ypp; % Predicted labels